<?php

return [
    'your_order_status_changed_subject' => 'Your order status is changed',
    'your_order_status_changed_text' => 'Status of your order #:order_id is changed to :status.',
];
