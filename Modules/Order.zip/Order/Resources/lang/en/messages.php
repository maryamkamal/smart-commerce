<?php

return [
    'status_updated' => 'Order status has been updated.',
    'invoice_sent' => 'Invoice has been sent to the customer.',
];
